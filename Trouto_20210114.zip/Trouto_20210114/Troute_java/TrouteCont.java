package kr.co.donghae.Troute;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import net.utility.Utility;



@Controller
public class TrouteCont {

	@Autowired
	TrouteDAO dao;
	
	
	public TrouteCont() {
		System.out.println("---TrouteCont() 객체 생성");
	}

//------------------------------------------------------------------------------------------------------------------------------------------
	
	@RequestMapping("Troute/Troute.do")
	public ModelAndView list(@ModelAttribute TrouteDTO dto, String tregion, HttpServletRequest req) {
		 ModelAndView mav=new ModelAndView();
		  mav.setViewName("Troute/TrouteList"); 
		  tregion=req.getParameter("tregion");
		  mav.addObject("tregion", tregion);
		  mav.addObject("list", dao.list(dto));
	  
		return mav;	
	}//loginForm end

//------------------------------------------------------------------------------------------------------------------------------------------
	@RequestMapping("Troute/TrouteRead.do")
	public ModelAndView read(@ModelAttribute String tregion, HttpServletRequest req) {
		 ModelAndView mav=new ModelAndView();
		  mav.setViewName("Troute/TrouteRead");
		  tregion=req.getParameter("tregion");
		  mav.addObject("tregion", tregion);
		
		return mav;	
	}//loginForm end
	

//------------------------------------------------------------------------------------------------------------------------------------------
	
	@RequestMapping("Troute/create.do")
	public ModelAndView create(ModelAndView mav) { 
		mav.setViewName("Troute/map");
		return mav;
	}//create.do

//------------------------------------------------------------------------------------------------------------------------------------------
	@RequestMapping("Troute/coninsert.do")
	public ModelAndView createget(ModelAndView mav, HttpServletRequest req) {
		if(req.getParameter("cno")!=null) {
			int cno=Integer.parseInt(req.getParameter("cno"));
			ArrayList<TrouteconDTO> list=dao.list(cno);
			mav.addObject("list", list);
		}
		
		if(req.getParameter("caddrw")==null) {
			
		}else {
			double caddrw=Double.parseDouble(req.getParameter("caddrw"));
			//System.out.println(caddrw);
			double caddrg=Double.parseDouble(req.getParameter("caddrg"));
			//System.out.println(caddrg);
			String csubject=req.getParameter("csubject");
			//System.out.println(csubject);
			String cregion=req.getParameter("cregion");
			//System.out.println(cregion);
			String cicon=req.getParameter("cicon");
			//System.out.println(cicon);
		
		int seq=dao.seqselect();
		int cno=seq+1;
		
		TrouteconDTO cdto=new TrouteconDTO();
		cdto.setCaddrW(caddrw);
		cdto.setCaddrG(caddrg);
		cdto.setCsubject(csubject);
		cdto.setCregion(cregion);
		cdto.setCicon(cicon);
		int cnt=dao.create(cdto,cno);		
		
		String msg="";
		if(cnt==0) {
			msg+="<script>alert('지도 내용 등록 실패했습니다');</script>";
		}else {
			msg+="<script>alert('지도 내용 등록 성공했습니다');</script>";
		}
		mav.addObject("msg",msg);
		ArrayList<TrouteconDTO> list=dao.list(cno);
		mav.addObject("list", list);
	}
		mav.setViewName("Troute/createForm");
		
		return mav;
	}//createget.do

//------------------------------------------------------------------------------------------------------------------------------------------
  
    @RequestMapping(value="/Troute/condelete.do",method=RequestMethod.GET)
    public ModelAndView delete(TrouteconDTO cdto, HttpServletRequest req) {
  	  ModelAndView mav= new ModelAndView();
        mav.setViewName("/Troute/msgView");
        mav.addObject("root",Utility.getRoot());
        String msg1="<p>이 여행지를 삭제하시겠습니까?</p>";
		String link1="<input type='button' value='삭제하기' onclick='location.href=\"condeleteproc.do?cconnum="+cdto.getCconnum()+"&cno="+cdto.getCno()+"\"'>";
		String link2="<input type='button' value='목록으로' onclick='javascript:history.back()'>";
		mav.addObject("msg1",msg1);
		mav.addObject("link1", link1);
		mav.addObject("link2", link2);
		mav.addObject("cdto",cdto);
  	  return mav;
    }//deleteForm() end
    

//------------------------------------------------------------------------------------------------------------------------------------------

    @RequestMapping(value="/Troute/condeleteproc.do",method=RequestMethod.GET)
    public ModelAndView deleteTpro(int cconnum,int cno, HttpServletRequest req) {
  	  ModelAndView mav= new ModelAndView();
        mav.setViewName("/Troute/msg");

  	  	String msg="";
  	  	cconnum=Integer.parseInt(req.getParameter("cconnum"));
  	  	cno=Integer.parseInt(req.getParameter("cno"));
  	  	//System.out.println(cconnum);
  	  	int cnt=dao.condelete(cconnum);
  	  	String root=Utility.getRoot();
  	  	System.out.println(cno);
  	  	if(cnt==0) {

  	  		msg+="<script>alert('삭제실패')</script>";
	    	msg+="<meta http-equiv='refresh' content='0;url="+root+"/Troute/coninsert.do?cno="+cno+"'>";

  	  	}else {
  	  		msg+="<script>alert('루트삭제성공')</script>";
	    	msg+="<meta http-equiv='refresh' content='0;url="+root+"/Troute/coninsert.do?cno="+cno+"'>";

  	  	}
  	  	mav.addObject("msg", msg);
  	  	req.setAttribute("cno", cno);
        
  	  return mav;
    }//deleteForm() end

    
    @RequestMapping(value="/Troute/addmemo.do", method = RequestMethod.POST)
    public ModelAndView addmemo(TrouteconDTO cdto, ModelAndView mav, HttpServletRequest req) {
    	int cconnum=cdto.getCconnum();

    	System.out.println(cconnum);
    	String cmemo=cdto.getCmemo();
    	System.out.println(cmemo);

    	mav.setViewName("Troute/createForm");
    	String msg="";
    	int cnt=dao.addmemo(cconnum, cmemo);
    	cmemo=req.getParameter("cmemo");
    	if(cnt==0) {
    		msg+="<script>alert('메모추가 실패')</script>";
    	}else {
    		
    		msg+="<script>alert('메모추가 성공'); opener.location.reload(); window.close();</script>";

    	}
    	mav.addObject("msg",msg);
    
    	return mav;
    }

    @RequestMapping(value="/Troute/addmemo.do", method = RequestMethod.GET)
    public ModelAndView addmemo(ModelAndView mav, HttpServletRequest req) {
    	int cconnum=Integer.parseInt(req.getParameter("cconnum"));
    	mav.addObject("cconnum",cconnum);
    	mav.setViewName("Troute/addmemo");
    
    	return mav;
    }
    
}//class end
