package kr.co.donghae.Troute;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import kr.co.donghae.Tpromotion.TpromotionDTO;
import kr.co.donghae.Treview.TreviewDTO;
import net.utility.DBClose;
import net.utility.DBOpen;

@Component
public class TrouteDAO {

	@Autowired
	DBOpen dbopen;
	
	@Autowired
	DBClose close;
	
	Connection con=null;
	PreparedStatement pstmt=null;
	ResultSet rs=null;
	StringBuilder sql=null;
	ArrayList<TrouteDTO> list=null;
	
	
	public TrouteDAO() {
		System.out.println("---TrouteDAO 객체 생성");
	}
	
	
	public ArrayList<TrouteDTO> list(TrouteDTO dto){
		ArrayList<TrouteDTO> list=null;
		try {
			con=dbopen.getConnection();
			sql=new StringBuilder();
	        sql.append(" SELECT tno, tsubject,tid,tdate, treadcnt, tlike, tmapsub, tmapcont, ticon, taddrw, taddrg, tregion");
	        sql.append(" FROM troute");
	        
	        if(dto.getTregion()!=null) {
	        	sql.append(" Where tregion=? ");
	        	sql.append(" ORDER BY tno desc ");
				pstmt = con.prepareStatement(sql.toString());
				pstmt.setString(1,  dto.getTregion());
			    rs=pstmt.executeQuery();

	        }else {
	        	sql.append(" ORDER BY tno desc ");
				pstmt = con.prepareStatement(sql.toString());
			    rs=pstmt.executeQuery();

	        }        	

        	

	      if(rs.next()) {
	        list=new ArrayList<TrouteDTO>(); 
	        do {
	        	dto=new TrouteDTO();
		        dto.setTno(rs.getInt("tno"));
		        dto.setTsubject(rs.getString("tsubject"));
		        dto.setTid(rs.getString("tid"));
		        dto.setTdate(rs.getTimestamp("tdate"));
		        dto.setTreadcnt(rs.getInt("treadcnt"));
		        dto.setTlike(rs.getInt("tlike"));
		        dto.setTmapsub(rs.getString("tmapsub"));
		        dto.setTmapcont(rs.getString("tmapcont"));
		        dto.setTicon(rs.getString("ticon"));
		        dto.setTaddrW(rs.getDouble("taddrw"));
		        dto.setTaddrG(rs.getDouble("taddrg"));
		        dto.setTregion(rs.getString("tregion"));
		        
				list.add(dto);
	        }while(rs.next());
	      }else {        
	        list=null;        
	      }//if end   
		}catch (Exception e) {
			System.out.println("목록실패:"+e);
		}finally {
			DBClose.close(con, pstmt, rs);
		}//end
		return list;
	}//list() end

	public TrouteDTO read(String tregion){
		TrouteDTO dto=null;
		try {
			con=dbopen.getConnection();
			
			sql=new StringBuilder();
			sql.append(" SELECT tno, tsubject,tid,tdate, treadcnt, tlike, tmapsub, tmapcont, ticon, taddrw, taddrg, tregion");
	        sql.append(" FROM Troute ");
	        sql.append(" WHERE tregion=? ");
	        
	        pstmt=con.prepareStatement(sql.toString());
	        pstmt.setString(1, tregion);
			
			rs=pstmt.executeQuery();
			if(rs.next()){
				dto=new TrouteDTO();
		        dto.setTno(rs.getInt("tno"));
		        dto.setTsubject(rs.getString("tsubject"));
		        dto.setTid(rs.getString("tid"));
		        dto.setTdate(rs.getTimestamp("tdate"));
		        dto.setTreadcnt(rs.getInt("treadcnt"));
		        dto.setTlike(rs.getInt("tlike"));
		        dto.setTmapsub(rs.getString("tmapsub"));
		        dto.setTmapcont(rs.getString("tmapcont"));
		        dto.setTicon(rs.getString("ticon"));
		        dto.setTaddrW(rs.getDouble("taddrw"));
		        dto.setTaddrG(rs.getDouble("taddrg"));
		        dto.setTregion(rs.getString("tregion"));
			}else{
				dto=null;
			}//if end
			
		}catch(Exception e) {
			System.out.println("미디어그룹 상세보기실패:"+e);
		}finally {
			DBClose.close(con,pstmt,rs);
		}//end
		
		return dto;
		
	}//read() end	
		
	public int seqselect() {
  	  int seq=0;

  	  try {
            con=dbopen.getConnection();
            sql=new StringBuilder();
            sql.append(" select max(Tno) from Troute");

            pstmt=con.prepareStatement(sql.toString());
            rs=pstmt.executeQuery();
            
            if(rs.next()) {
	              seq=rs.getInt("max(Tno)");
            }else {
                seq=0;
            }//if end
         }catch(Exception e) {
            System.out.println("숫자불러오기 실패" + e);
         }finally {
            DBClose.close(con,pstmt,rs);
         }//end
  	  
  	  return seq;
    }
	
	public int create(TrouteconDTO cdto, int cno){
		int cnt=0;
		try {
			con=dbopen.getConnection();
			
			sql=new StringBuilder();
			sql.append(" insert into troutecon (cconnum, cno, caddrw, caddrg, csubject, cicon, cregion, cmemo)");
			sql.append(" values(Cconnum_seq.nextval , ?, ?, ?, ?, ?, ? ,'') ");
	        pstmt=con.prepareStatement(sql.toString());
	        pstmt.setInt(1, cno);
	        pstmt.setDouble(2, cdto.getCaddrW());
	        pstmt.setDouble(3,cdto.getCaddrG());
	        pstmt.setString(4, cdto.getCsubject());
	        pstmt.setString(5, cdto.getCicon());
	        pstmt.setString(6, cdto.getCregion());
	        
			cnt=pstmt.executeUpdate();
			
		}catch(Exception e) {
			System.out.println("지도 내용 추가 실패:"+e);
		}finally {
			DBClose.close(con,pstmt,rs);
		}//end
		
		return cnt;
		
	}//read() end	
	
	
	
	public ArrayList<TrouteconDTO> list(int cno){
		ArrayList<TrouteconDTO> list=new ArrayList<TrouteconDTO>();
		try {
			con=dbopen.getConnection();
			sql=new StringBuilder();
			sql.append(" SELECT cconnum, cno, caddrw, caddrg, csubject, cmemo, cicon, cregion");
	        sql.append(" FROM Troutecon Where cno=? ORDER BY cconnum ");
	        pstmt = con.prepareStatement(sql.toString());
			pstmt.setInt(1, cno);
			rs=pstmt.executeQuery();
			if(rs.next()) {
				do {
	        	TrouteconDTO cdto=new TrouteconDTO();
		        cdto.setCconnum(rs.getInt("cconnum"));
				cdto.setCno(rs.getInt("cno"));
				cdto.setCaddrW(rs.getDouble("caddrw"));
				cdto.setCaddrG(rs.getDouble("caddrg"));
				cdto.setCsubject(rs.getString("csubject"));
				cdto.setCmemo(rs.getString("cmemo"));
				cdto.setCicon(rs.getString("cicon"));
				cdto.setCregion(rs.getString("cregion"));
				list.add(cdto);
				}while(rs.next());
	      }else {        
	        list=null;        
	      }//if end   
		}catch (Exception e) {
			System.out.println("지도 상세목록실패:"+e);
		}finally {
			DBClose.close(con, pstmt, rs);
		}//end
		return list;
	}//list() end

	public int condelete(int cconnum) {
		int cnt=0;
		try {
			con=dbopen.getConnection();
			sql=new StringBuilder();
			sql.append(" Delete From Troutecon");
			sql.append(" Where cconnum=?");
			pstmt=con.prepareStatement(sql.toString());
			pstmt.setInt(1, cconnum);
			cnt=pstmt.executeUpdate();
			System.out.println(cnt);
		} catch (Exception e) {
			System.out.println("삭제실패"+e);
		}finally {
			DBClose.close(con,pstmt);
		}//end
	
		return cnt;
	}//condelete() end
	
	
	
	public int addmemo(int cconnum, String cmemo){
		int cnt=0;
		try {
			con=dbopen.getConnection();
			
			sql=new StringBuilder();
			sql.append(" Update troutecon set cmemo=?");
			sql.append(" Where cconnum=?");
			
	        pstmt=con.prepareStatement(sql.toString());
	        pstmt.setString(1, cmemo);
	        pstmt.setInt(2, cconnum);

	        
			cnt=pstmt.executeUpdate();
			
		}catch(Exception e) {
			System.out.println("메모 추가 실패:"+e);
		}finally {
			DBClose.close(con,pstmt,rs);
		}//end
		
		return cnt;
		
	}//addmemo() end	

}//class end
