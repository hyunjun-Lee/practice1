package kr.co.donghae.Troute;

public class TrouteconDTO {

	int Cconnum;
	int Cno;
	double CaddrW;    
	double CaddrG;
	String Csubject; 
	String Cmemo;    
	String Cicon;
	String Cregion;
	
	
	public int getCconnum() {
		return Cconnum;
	}
	public void setCconnum(int cconnum) {
		Cconnum = cconnum;
	}
	public int getCno() {
		return Cno;
	}
	public void setCno(int cno) {
		Cno = cno;
	}
	public double getCaddrW() {
		return CaddrW;
	}
	public void setCaddrW(double caddrW) {
		CaddrW = caddrW;
	}
	public double getCaddrG() {
		return CaddrG;
	}
	public void setCaddrG(double caddrG) {
		CaddrG = caddrG;
	}
	public String getCsubject() {
		return Csubject;
	}
	public void setCsubject(String csubject) {
		Csubject = csubject;
	}
	public String getCmemo() {
		return Cmemo;
	}
	public void setCmemo(String cmemo) {
		Cmemo = cmemo;
	}
	public String getCicon() {
		return Cicon;
	}
	public void setCicon(String cicon) {
		Cicon = cicon;
	}
	public String getCregion() {
		return Cregion;
	}
	public void setCregion(String cregion) {
		Cregion = cregion;
	}
	
	
	@Override
	public String toString() {
		return "TrouteconDTO [Cconnum=" + Cconnum + ", Cno=" + Cno + ", CaddrW=" + CaddrW + ", CaddrG=" + CaddrG
				+ ", Csubject=" + Csubject + ", Cmemo=" + Cmemo + ", Cicon=" + Cicon + ", Cregion=" + Cregion + "]";
	}
	
	
}//end
